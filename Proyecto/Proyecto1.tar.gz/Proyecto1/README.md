# Evolutivo
Proyecto de Algoritmos geneticos
solucionando el problema del agente viajero

Daniela Calderón Pérez 311002209
Jonathan Barragán Jiménez 311139163

Para poder leer el archivo, es necesario que se encuentre dentro de la carpeta build y que sea en formato .txt, así como el que se anexa en la carpeta.

Tuvimos problemas para leer los archivos, nos tardamos mucho en esa parte, en lo demás creemos que estamos bien. Probamos ese archivo, y se puede ver la ejecución del algoritmo con ayuda de la herramienta gráfica del framework.

En cuanto al reporte, espero podamos terminarlo en unas horas, mientras tanto, este es el adelanto más decente que tenemos.
*Nota: Los resultados en las tablas, no representan los resultados originales.
